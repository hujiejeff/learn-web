//路由

class Router {
    /**
     * /home
     * /about
     * @param {string} url 
     */
    static to({url, scriptSrc}) {
        history.pushState({}, '测试', url);
        let contentEl = document.querySelector('content');
        let script = document.createElement('script');
        script.src = scriptSrc;
    }


}

