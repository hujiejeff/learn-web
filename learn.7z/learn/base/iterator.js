let arr = [1,2,3,4];

let it = {
  [Symbol.iterator]: function () {
    return {
      index: 0,
      next() {
        if (this.index < arr.length) {
          return { value: arr[this.index++], done: false };
        }
        else return { value: null, done: true };
      }
    }
  }

}

for (let age of it) {
  console.log(age);
}


function Node(value) {
  this.value = value;
  this.next = null;
}

Node.prototype[Symbol.iterator] = function() {
  var iterator = {next};
  var current = this;
  function next() {
    if (current) {
      var value = current.value;
      current = current.next;
      return {done: false, value: value};
    } else {
      return {done: true};
    }
  }
  return iterator;
}

let one = new Node("one");
let two = new Node("tow");
let three = new Node("three");
one.next = two;
two.next = three;
for (let node of one) {
  console.log(node)
}
