function duplicates(arr) {
    let set = new Set(arr);
    let arr2 = [...set];
    console.log(arr2);
    for (let i = 0; i < arr2.length; i++) {
        let count = 0;
        for (let j = 0; j < arr.length; j++) {
            if (arr2[i] === arr[j]) {
                count++;
            }
        }
        if (count >= 1) {
            set.delete(i);
        }
    }

    return [...set];
}

let arrr = duplicates([1, 2, 3, 4, 5, 1, 2, 3]);
console.log(arrr);

let a = 10;
function show () {
    console.log(a);
}
show();

window.onbeforeunload