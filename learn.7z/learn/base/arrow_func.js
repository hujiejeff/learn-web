let name = (name) => name + 'fff';
console.log(name('hujie'));

class A {
    show = () => {
        console.log(this instanceof A)
    }
    constructor() {
        
    }
    show2() {
        console.log(this)
    }
}

let aa = new A();
aa.show();
aa.show2();
aa.show.bind