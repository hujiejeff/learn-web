let name = 'jack';
let age = 18;

export { name, age };
