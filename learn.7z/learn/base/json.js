let arr = [1,2,3,4];
let str = JSON.stringify(arr);
console.log(str);
let arr2 = JSON.parse(str);
console.log(arr2);


let obj = {
    name: 'hujie',
    like: {
        eat: true,
        music: 'sss'
    },
    age: 22
}

let str2 = JSON.stringify(obj, null, 2);
console.log(str2);

// let xhr = new XMLHttpRequest();
// xhr.open();

// try {
//     if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
//         alert(xhr.responseText);
//     } else {
//         alert("Request was unsuccessful: " + xhr.status);
//     }
// } catch (ex) {
//     //假设由 ontimeout 事件处理程序处理
// } 


function getSome() {
    console.log('old')
    let flag = true;
    if(flag) {
        getSome = function() {
            return "fffff"
        }
    } else {
        getSome = function() {
            return "1223";
        }
    }
    return getSome();
}

let s = getSome();
let s2 = getSome();
let s3 = getSome();
console.log(s);
console.log(s2);
console.log(s3);

let getSome2 = (function(){
    let flag = false;
    let tmp;
    if (flag) {
        tmp = function () {
            return "fffff"
        }
    } else {
        tmp = function () {
            return "1223";
        }
    }
    return tmp;
})();

Object.apply