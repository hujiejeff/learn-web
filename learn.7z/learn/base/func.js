function test1() {
    console.log(this);
}

let test2 = () => {
    console.log(this);
}

let obj = {};
obj.test3 = function() {
    console.log(this);
    (() => {
        console.log('innner func')
        console.log(this);
    })();
}

obj.test4 = () => {
    console.log(this);
}

test1();
test2();
obj.test3();
obj.test4();

console.log(obj.toString());