// 'use strict';
var arr = [1,2,3];
arr.forEach(function(x) {
    console.log(x+1);
});

function hello(name) {
    console.log("hello " + name + "!");
}

var sayHello = function (name) {
    console.log("hello " + name + "!");
    console.log(arguments);
};

var sayHello2 = hello;

sayHello("hujie", "fdaf");


function foo(x) {
    console.log('x = ' + x); // 10
    for (var i = 0; i < arguments.length; i++) {
        console.log('arg ' + i + ' = ' + arguments[i]); // 10, 20, 30
    }
}
foo(10, 20, 30);

function fooRst(a, b, ...rest) {
    console.log('a = ' + a);
    console.log('b = ' + b);
    console.log(rest);
    console.log(arguments);
}

fooRst(1,2,3,4,5);
var a = [1,23,4];
console.log(a);


function foo3() {
    for (var i = 0; i < 100; i++) {
        //
    }
    i += 100; // 仍然可以引用变量i
    console.log(i);
}

foo3();

//对象结构，同样嵌套同上
var person = {
    name: '小明',
    age: 20,
    gender: 'male',
    passport: 'G-12345678',
    school: 'No.4 middle school'
};
// var { name, age, passport } = person;

//切换变量名
var { name: myName, age, passport } = person;
console.log(myName);//小明
//console.log(name);//undefined

var x =1, y=2;
// 解构赋值:
[x,y] = [y, x];
console.log([x,y]);


var person = {
    name: "jeff",
    age: 18,
    hello: function () {
        //this指向person
        console.log(this.name + "-" + this.age);
    },
    show: function () {
        var mes = "hello";
        function innerShow() {
            //严格模式下，error，因为this指向不到person
            console.log(this.name);
        }
        return innerShow();
    }
}

// person.show();


var jeff = {
    name: "jeff",
    age: 18
};
function show() {
    console.log(this);//默认外部上下文
}
//传入对象，以及参数列表
show.apply(undefined, []);
show.apply(jeff, []);
show.call(jeff);



//装饰器模式，装饰函数
var oldLog = console.log;
console.log = function(obj) {
    oldLog.call(this, "decoreate");
    return oldLog(obj);
}

console.log("fdafd");

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
arr.map(String); // ['1', '2', '3', '4', '5', '6', '7', '8', '9']
console.log(arr)

function count() {
    var arr = [];
    for (var i = 1; i <= 3; i++) {
        arr.push((function (n) {
            return function () {
                return n * n;
            }
        })(i));
    }
    return arr;
}

var results = count();
var f1 = results[0];
var f2 = results[1];
var f3 = results[2];

f1(); // 1
f2(); // 4
f3(); // 9

function* foo(x) {
    yield x + 1;
    yield x + 2;
    return x + 3;
}

var f = foo(1);
console.log(f.next());
console.log(f.next());
console.log(f.next());


var xiaoming = {
    name: '小明',
    age: 14,
    gender: true,
    height: 1.65,
    grade: null,
    'middle-school': '\"W3C\" Middle School',
    skills: ['JavaScript', 'Java', 'Python', 'Lisp']
};
var s = JSON.stringify(xiaoming);
console.log(s);

var xy = {
    'x':1,
    'y':2
};
console.log(xy);
xy.x
function convert(key, value) {
    if (typeof value === 'string') {
        return value.toUpperCase();
    }
   return value;
}




var s = JSON.stringify(xiaoming, (key, value) => {
    if(typeof value === 'string') {
        return value.toUpperCase();
    }
    return value;
}, '    ');
console.log(s);


new Promise(function (resolve, reject) {
    console.log('start new Promise...');
    var timeOut = Math.random() * 2;
    console.log('set timeout to: ' + timeOut + ' seconds.');
    setTimeout(function () {
        if (timeOut < 1) {
            console.log('call resolve()...');
            resolve('200 OK');
        }
        else {
            console.log('call reject()...');
            reject('timeout in ' + timeOut + ' seconds.');
        }
    }, timeOut * 1000);
}).then(function (r) {
    console.log('Done: ' + r);
}).catch(function (reason) {
    console.log('Failed: ' + reason);
});


