function createSingleton() {
    let obj = { name: 'obj', des: 'des' };
    return function () {
        return obj;
    }
}

let getInstance = createSingleton();

let obj1 = getInstance();
obj1.name = 'kkk';

let obj2 = getInstance();

console.log(obj1);
console.log(obj2);
console.log(obj2 === obj1);
let Player;

(function () {
    let instance = null;
    Player = class {
        constructor() {
            if (instance === null) {
                this.name = "jeff";
                instance = this;
            }
            return instance;
        }
    }
}());

let instance1 = new Player();
let instance2 = new Player();
let instance3 = new Player();
console.log(instance1 === instance2);
console.log(instance1 === instance3);


class Singleton {
    static #instance = null;
    constructor() {
        if (Singleton.#instance == null) {
            this.name = 'kk';
            this.age = 18;
            Singleton.#instance = this;
        }
        return Singleton.#instance;

    }

    static getInstance() {
        return new Singleton();
    }
}

let a = Singleton.getInstance();
let b = Singleton.getInstance();
let c = new Singleton();
console.log(a === b);
console.log(a === c);

