class KK {
    name = 'k';
    show() {
        console.log('xx')
    }
}

let k = new KK();
console.log(k.name)

let fn = function(...args) {
    console.log(this.name);
    console.log({...args})
}


fn.apply(k,['fdaf',1,3]);
fn.call(k, 1,2,3,4);
let kk2 = new KK();
kk2.name = 'kk2';
let fn2 = fn.bind(kk2, 1,2,3,4,[1,2,3,4]);
fn2();
fn2();

//自实现bind
function myBind(fn, thisArg, ...args) {
    return function() {
        fn.call(thisArg, ...args);
    }
}
let kk3 = new KK();
kk3.name = 'kk3';
let fn3 = myBind(fn, kk3, 1,2,3,4);
fn3();
fn3();
fn3();

// //自实现apply
// Function.prototype.apply = function(context, ...args) {
//     context.__fn = this;
//     context.__fn(...args);
//     console.log('xxx');
//     delete context.__fn;
// }

// fn.apply(k, 1,4,5);


//柯里化
function curry(fn) {
    let args = Array.prototype.slice.call(arguments, 1);
    return function() {
        let innerArgs = Array.prototype.slice.call(arguments);
        let finalArgs = args.concat(innerArgs);
        return fn.apply(null, finalArgs);
    }
}

function add(a, b) {
    return a + b;
} 

let curryAdd = curry(add, 1);
console.log(curryAdd(2));
'use strict'

let obj = {name: 'jeff'};
Reflect.preventExtensions(obj);
obj.age = 12;
console.log(obj.age);
console.log(Reflect.isExtensible(obj));
delete obj.name;
console.log(obj);