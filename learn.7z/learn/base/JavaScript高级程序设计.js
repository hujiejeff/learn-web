'use strict';
let log = console.log;
function show() {

}

log(typeof show);

let a;
let b = undefined;
log(a);
log(b);

log(undefined == null);
log(undefined === null);

function changeObj(obj) {
    obj.name = 'hujie';
}

let obj = {
    name: 'jeff',
    age: 20
};

log(obj);
changeObj(obj);
log(obj);


function showArgsment() {
    console.log();
}

let ab = "string";

let Person = (function(){
    let name;
    function Person() {
        name = 'hujie';
    }

    Person.hello = function() {
        console.log('hello');
    }

    Person.prototype.setName = function(value) {
        name = value;
    }

    Person.prototype.getName = function() {
        return name;
    }

    Person.prototype.show = function() {
        console.log('show ' + name);
    }
    return Person;
})();
Person.hello();
let person = new Person();
person.show();
person.setName('kk');
person.show();
console.log(person);

function A() {
    let obj = new Object();
    obj.name = 'kk';
    return obj;
}

let aa = new A();

console.log(Object.getPrototypeOf(aa).constructor);
console.log(aa instanceof A);

(function(){
    
})();