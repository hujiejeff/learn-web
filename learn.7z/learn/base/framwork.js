(function () {
    let moduleMap = {};
    let fileMap = {};
    let noop = function () { };
    let thin = {
        define(name, dependencies, factory) {
            if (!moduleMap[name]) {
                let module = { name, dependencies, factory };
                moduleMap[name] = module;
            }
            return moduleMap[name];
        },
        use(name) {
            let module = moduleMap[name];
            if (!module.entity) {
                let args = [];
                for (let dependency of module.dependencies) {
                    if (moduleMap[dependency].entity) {
                        args.push(moduleMap[dependency].entity);
                    } else {
                        args.push(this.use(dependency));
                    }
                }
                module.entity = module.factory.apply(noop, args);
            }
            return module.entity;
        },
        require(pathArr, callback) {
            for (let path of pathArr) {
                if (!fileMap[path]) {
                    let head = document.getElementsByTagName('head')[0];
                    let node = document.createElement('script');
                    node.type = 'javascript';
                    node.async = 'true';
                    node.src = `${path}.js`;
                    node.onload = function () {
                        fileMap[path] = true;
                        head.removeChild(node);
                        checkAllFiles();
                    };
                    head.appendChild(node);
                }
            }

            function checkAllFiles() {
                let allLoaded = true;
                for (let path of pathArr) {
                    if (!fileMap[path]) {
                        allLoaded = false;
                        break;
                    }
                }
                if (allLoaded) {
                    callback();
                }
            }
        }
    };
    window.thin = thin;
}());

//test
thin.define('constant.PI', [], function () {
    return 3.1415926;
});

thin.define('shape.Circle', ['constant.PI'], function (pi) {
    class Circle {
        constructor(r) {
            this.r = r;
        }

        area() {
            return pi * this.r * this.r;
        }
    }

    return Circle;
});

thin.define('shape.Rectangle', [], function () {
    class Rectangle {
        constructor(w, h) {
            this.w = w;
            this.h = h;
        }

        area() {
            return this.w * this.h;
        }
    }

    return Rectangle;
});

thin.define('ShapeTypes', ['shape.Circle', 'shape.Rectangle'], function (Circle, Rectangle) {
    return {
        CIRCLE: Circle,
        RECTANGLE: Rectangle,
    };
});

thin.define('ShapeFactory', ['ShapeTypes'], function (ShapeTypes) {
    return {
        getShape(type, ...rest) {
            return new ShapeTypes[type](...rest);
        }
    };
});

let ShapeFactory = thin.use('ShapeFactory');
console.log(ShapeFactory.getShape('CIRCLE', 10));
console.log(ShapeFactory.getShape('RECTANGLE', 10, 20));


let template = `
<div>
    <ul>
        <li>测试1</li>
        <li>测试2</li>
        <li>测试3</li>
    </ul>
</div>
`;

let tmpEl = document.createElement('div');
tmpEl.innerHTML = template;
let el = tmpEl.children[0];
console.log(el);
el.classList = 'main';
let scriptEl = document.querySelector('script');
console.log(scriptEl);
document.querySelector('body').insertBefore(el, scriptEl);
// document.getElementsByTagName('body')[0].appendChild(el);

function createElement(template) {
    let tmp = document.createComment('div');
    tmp.innerHTML = template;
    let el = tmp.children[0];
    return el;
}

function $(selectors) {
    return document.querySelector(selectors);
}

console.log($('body div'));

