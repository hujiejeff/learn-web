function deepClone(value) {
    let result;
    //基本类型
    if (!isObject(value)) {
        return value;
    }

    const isArray = Array.isArray(value);
    const tag = getTag(value);
    //是数组
    if (isArray) {
        //初始化
        result = initCloneArray(value);
        //赋值
        for (let i; i < value.length; i++) {
            result[i] = deepClone(value[i]);
        }
        return result;
    }
    const isFunc = type === "function";
    if (isFunc) {
        return value;
    }

    //对象或arguments
    if (tag == "[object Object]" || tag == "[object Arguments]") {
        result = initCloneObject(value);
    } else {
        result = initCloneByTag(value, tag);
    }

    Object.keys(Object(value)).forEach(k => {
        result[k] = deepClone(value[k]);
    });

    return result;
}

const hasOwnProperty = Object.prototype.hasOwnProperty;

function isObject(value) {
    const type = typeof value;
    return type != null && (type === "object" || type === "function");
}

//数据初始化
function initCloneArray(array) {
    const { length } = array;
    const result = new array.constructor(length);

    //RegExp.prototype.exec() 会返回一个数组或null，而这个数组中含有特殊属性input、index
    if (
        length &&
        typeof array[0] === "string" &&
        hasOwnProperty.call(array, "index")
    ) {
        result.index = array.index;
        result.input = array.input;
    }
    return result;
}

//细致判断对象类型
const toString = String.prototype.toString;
function getTag(value) {
    if (value == null) {
        return value === undefined ? "[object Undefined]" : "[object Null]";
    }
    return toString.call(value);
}

const objectProto = Object.prototype;
function isPrototype(value) {
    const Ctor = value && value.constructor;
    const proto = (typeof Ctor === "function" && Ctor.prototype) || objectProto;
    return value === proto;
}

//初始化对象

function initCloneObject(object) {
    return typeof object.constructor === "function" && !isPrototype(object)
        ? Object.create(Object.getPrototypeOf(object))
        : {};
}

//特殊对象初始化
function initCloneByTag(object, tag, isDeep) {
    const Ctor = object.constructor;
    switch (tag) {
        case "[object Boolean]":
        case "[object Date]":
            return new Ctor(+object);
        case "[object Set]":
        case "[object Map]":
            return new Ctor();
        case "[object Number]":
        case "[object String]":
            return new Ctor(object);
        case "[object RegExp]":
            return cloneRegExp(object);
        case "[object Symbol]":
            return cloneSymbol(object);
        default:
            return;
    }
}

const reFlags = /\w*$/;
function cloneRegExp(regExp) {
    const result = new regExp.constructor(regExp.source, reFlags.exec(regExp));
    result.lastIndex = regExp.lastIndex;
    return result;
}

const symbolValueOf = Symbol.prototype.valueOf;
function cloneSymbol(symbol) {
    return Object(symbolValueOf.call(symbol));
}
