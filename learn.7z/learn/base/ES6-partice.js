'use strict';
let {log} = console;
function move({x:k = 0, y =0} = {}) {
    return [k,y];
}
let a =move({x:1,y:2});
let b = move({x:2});
let c = move();
// let d= move(null);
log(a);
log(b);
log(c);
// log(d);
