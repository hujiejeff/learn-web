
let start = new Date();
setTimeout(function () {
    console.log('timer trigger!');
}, 10)
for (let i = 0; i < 1000; i++) {
    console.log(i);
}
let end = new Date();
console.log((end - start) + 'ms');

function test() {
    'use strict'
    console.log(arguments.callee)
}

test();