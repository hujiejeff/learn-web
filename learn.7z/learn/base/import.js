import { name, age } from './export.js'

console.log(name, age);