'use strict';

function compile(tmeplate) {
    const evalExpr = /<%=(.+?)%>/g;
    const expr = /<%([\s\S]+?)%>/g;
    tmeplate = tmeplate
        .replace(evalExpr, '`); \n echo ($1); \n echo (`')
        .replace(expr, '`); \n $1 \n echo (`');
    tmeplate = 'echo (`' + tmeplate + '`);';
    let script =
        `
    (function parse(data){
        let output = "";
        function echo(html) {
            output += html;
        }
        ${tmeplate}
        return output;
    })`;
    return script;
}
let template = `
<ul>
  <% for(let i=0; i < data.supplies.length; i++) { %>
    <li><%= data.supplies[i] %></li>
  <% } %>
</ul>
`;
let script = compile(template);
console.log(script);
let parse = eval(script);
console.log(parse({
    supplies: ["Bromm", "mop", "cleaner"]
}));

function pass(argss, ...res) {
    console.log(argss);
    console.log(res);
    console.log(arguments);
}

pass([1, 23], 1, 3, 4);


let total = 30;
let msg = passthru`${total - 30} The total is ${total} (${total * 1.05} with tax ${total - 2})`;

function passthru(literals) {
    let result = '';
    let i = 0;
    console.log(literals.raw[0]);
    while (i < literals.length) {
        result += literals[i++];
        if (i < arguments.length) {
            result += arguments[i];
        }
    }

    return result;
}

console.log(msg);

tag`First line\nSecond line`

function tag(strings) {
    console.log(strings.raw[0]);
    console.log(strings[0]);
    // strings.raw[0] 为 "First line\\nSecond line"
    // 打印输出 "First line\nSecond line"
}


function throwIfMissing() {
    throw new Error('Missing parameter');
}

function foo(mustBeProvided = throwIfMissing()) {
    return mustBeProvided;
}

// foo();

function factorial1(n) {
    if (n === 1) return 1;
    else return n * factorial(n - 1);
}

function factorial(n, total) {
    if (n === 1) return 1;
    else return factorial(n - 1, n * total);
}

function fibonacci(n) {
    if (n <= 0) return;
    if (n === 1 || n == 2) {
        return 1;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}

function fibonacci2(n, ac1 = 1, ac2 = 1) {
    if (n <= 1) { return ac2 };
    return fibonacci2(n - 1, ac2, ac1 + ac2);
}

let obj = new Object();
console.log(fibonacci.__proto__.__proto__);

function timeout(ms) {
    return new Promise((resolve, reject) => {
        console.log("timeout");
        setTimeout(resolve, ms, 'done');
    });
}

timeout(2000).then((value) => {
    console.log(value);
});


const getJSON = function (url) {
    const promise = new Promise(function (resolve, reject) {
        const handler = function () {
            if (this.readyState !== 4) {
                return;
            }
            if (this.status === 200) {
                resolve(JSON.parse(this.response));
            } else {
                reject(new Error(this.statusText));
            }
        };
        const client = new XMLHttpRequest();
        client.open("GET", url);
        client.onreadystatechange = handler;
        client.responseType = "json";
        client.setRequestHeader("Accept", "application/json");
        client.send();
    });
    return promise;
}

// getJSON("/posts.json").then(function(json) {
//   console.log("Contents: " + json);
// }, function(error) {
//   console.log("出错了 ", error);
// });

const promises = [1, 2, 3, 10].map(function (value) {
    return timeout(value * 1000);
});

Promise.all(promises).then(function (value) {
    console.log(value);
});


function* get() {
    yield 1;
    yield 2;
}

console.log(get().next());
console.log(get().next());