//模拟异步任务
function timeout(ms) {
  return new Promise(function (resolve, reject) {
    console.log(`开始执行异步,等待${ms / 1000}s`);
    setTimeout(resolve, ms);
  });
}

async function asyncPrint(value, ms) {
  await timeout(ms).then(function () {
    console.log("1号 执行完毕");
  });

  console.log("2号开始执行");
  await timeout(2000).then(() => console.log("2号 执行完毕"));
  console.log("全部执行完毕");
}

async function syncPrint() {
  let taskA = timeout(2000).then(() => console.log("1号执行完毕"));
  let taskB = timeout(3000).then(() => console.log("2号执行完毕"));
  await taskA;
  await taskB;
}

// asyncPrint('hello world', 3000).then(function() {
//   console.log("test");
// });


syncPrint().then(() => {
  console.log("执行完毕");
});

async function fn(args) {
  //task by awit
}

function fn2(args) {
  return spawn(function* () {
    //task by yield
  });
}

//基于生成器的自动执行任务
function spawn(genF) {
  return new Promise(function (resolve, reject) {
    const gen = genF();
    function step(nextF) {
      let next;
      try {
        next = nextF();
      } catch (e) {
        return reject(e);
      }
      if (next.done) {
        return resolve(next.value);
      }
      Promise.resolve(next.value).then(function (v) {
        step(function () { return gen.next(v); });
      }, function (e) {
        step(function () { return gen.throw(e); });
      });
    }
    step(gen.next(undefined));
  });
}


Object.defineProperties(Number.prototype, { second: { get() { return this * 1000 } } });
Object.defineProperty(Number.prototype, 'minute', { get() { return this * 1000 * 60 } });
Object.defineProperty(Number.prototype, 'hour', {
  get() { 
    let that = this;
    return function() {
      return that * 1000 * 60 * 60;
    }
   }
});

Object.assign(Number, {one: 1});
Number.two = 2;

Object.assign(Number.prototype, {one:function(){return this * 10}});
Object.assign(Number.prototype, {get s() {return 6;}});
console.log((1).second);
console.log((1).minute);
console.log((1).hour());
console.log((2).one());
console.log((2).s);

console.log(Number.one);
console.log(Number.two);

let arr = [1,2,3];
let newArr = arr.slice(0, arr.length - 1);

console.log(newArr);


