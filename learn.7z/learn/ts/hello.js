function hello(str) {
    console.log(str);
}
hello('hello');
var p = {
    name: 'hujie',
    age: 18,
    address: 'xxx'
};
console.log();
function show(age) {
    console.log(age);
}
var A = /** @class */ (function () {
    function A() {
        this.name = 'tome';
    }
    A.prototype.show = function () {
        console.log(this.name);
    };
    return A;
}());
var a = new A();
a.show();
var BB = /** @class */ (function () {
    function BB() {
        this.name = 10;
    }
    BB.prototype.getName = function () {
        return name;
    };
    return BB;
}());
var bb = new BB();
var MyArray = /** @class */ (function () {
    function MyArray() {
        var res = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            res[_i] = arguments[_i];
        }
        for (var index in res) {
            this[index] = res[index];
        }
        this.length = res.length;
    }
    return MyArray;
}());
var arr = new MyArray('1', '222', 'aaaa');
console.log(arr);
console.log(arr[1]);
let arr2 = new Array();
arr2.push(222);
arr2.push(222);
arr2.push(222);
console.log(arr2);
let names = Object.getOwnPropertyNames(arr2);
console.log(names);
