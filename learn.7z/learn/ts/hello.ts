function hello(str: string) {
    console.log(str)
}

hello('hello')

interface Person {
    name: string,
    age?: number,
    [propName: string]: any
}

let p: Person = {
    name: 'hujie',
    age: 18,
    address: 'xxx'
}
console.log()

type AgeInt = 1 | 2 | 3;
function show(age: AgeInt) {
    console.log(age);
}


class A {
    private name: string = 'tome'
    public show() {
        console.log(this.name);
    }
}

let a = new A();
a.show();

class BB {
    private name = 10;
    public getName(): string {
        return name;
    }
}

let bb: BB = new BB();

class MyArray {
    [index: number]: string;
    length: number;
    constructor(...res: string[]) {
        for (let index in res) {
            this[index] = res[index];
        } 
        this.length = res.length;
    }
}

let arr = new MyArray('1', '222', 'aaaa');
console.log(arr);
